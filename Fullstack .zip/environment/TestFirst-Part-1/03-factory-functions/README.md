### 03-Factory-Functions

<hr>

### Overview

Using your knowledge of Factory Functions, apply the Factory Function pattern to the `createCalculator` function

As you progress through the calculator specs, you may notice that to pass all the specs, methods may need to be able to reference the object that they belong to. This is a great introduction to the `this` keyword!
