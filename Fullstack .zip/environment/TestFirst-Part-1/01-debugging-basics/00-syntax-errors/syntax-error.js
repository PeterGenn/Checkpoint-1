/* eslint-disable no-unused-vars */
const hi = 'hi';
const bye = 'bye';
const world = 'world'

function helloWorld() {
  return `${hi} ${world}`
}
const goodbyeWorld = (string) => {
   good: 'good',
   bye,
   world
}
