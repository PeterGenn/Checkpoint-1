const paris = 'paris';
const marsielle = france;

const vacationSpots = (spot1, spot2) => {
  if (spot.length > spot2.length) {
    return spot1;
  }
  return spot2;
};
