/* eslint-disable no-unused-vars */
function hello(name) {
  if (typeof name === 'undefined') {
    return 'Hello!';
  } else {
    return `Hello, ${name}!`;
  }
}

function add(number, num) {
  return number + num;
}
