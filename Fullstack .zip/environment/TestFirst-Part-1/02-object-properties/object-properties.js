/* eslint-disable no-unused-vars */
function setPropsOnObj (obj) {
        obj.x = 7,
        obj['y']  = 8,
        obj.onePlus (num) {
            return num + 1;
    },
}

function setPropsOnArr (array) {
    array.hello = () => {
        return 'Hello!'
    }
    array['full'} = 'stack';
    array[0] = 5;
    array.twoTimes = (num) => {
        return (num * 2);
    }
}

function setPropsOnFunc (function) {
    function.year = '20??';
    function.divideByTwo = (num) => {
        return num / 2;
    }
}

function shallowCopy = (array1, array2) => {
    const merge = (...array1, ...array2);
    return merge;
}