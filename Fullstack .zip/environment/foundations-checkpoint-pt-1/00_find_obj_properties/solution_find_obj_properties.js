const findObjPropsHasOwn = () => {
    const rectanglePrototype = {
      getArea: function () {
        return this.height * this.width;
          
      },
  };
  function rectangle(color, height, width) {
    const rectangleInstance = Object.create(rectanglePrototype);

    rectangleInstance.color = this.color;
    rectangleInstance.height = this.height;
    rectangleInstance.width = this.width;

    return rectangleInstance;
  }

function findObjKeys (obj) {
    const objInstance = Object.create(obj)
    for (let key in objInstance) {
        return objInstance[key];
    }
} 
// const findObjPropsHasOwn = () => {
//   const rectanglePrototype = {
//     getArea: function () {
//       return this.height * this.width;
//     },
//   };
//   function rectangle(color, height, width) {
//     const rectangleInstance = Object.create(rectanglePrototype);

//     rectangleInstance.color = this.color;
//     rectangleInstance.height = this.height;
//     rectangleInstance.width = this.width;

//     return rectangleInstance;
//   }
  

      
//   }
  
  